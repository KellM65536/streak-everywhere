function animatePopIn(element){
    const SECOND_IN_FRAMES = 200
    let animationFrame = 0
    let id = null
    let y = -10.0
    let yVel = 6.0

    clearInterval(id);
    id = setInterval(stepPopIn, 5);

    element.addEventListener("click", () => {
        clearInterval(id);
        element.remove()
    })

    function stepPopIn(){
        if(animationFrame < SECOND_IN_FRAMES * 0.3){
            y += yVel
            yVel *= 0.5
            element.style.top = y + "rem"
        } else if (animationFrame < SECOND_IN_FRAMES * 8.3) {
            yVel = 0 // -6.0
        } else if (animationFrame < SECOND_IN_FRAMES * 8.6) {
            y += yVel
            yVel += -0.2
            // yVel *= 0.5
            element.style.top = y + "rem"
        } else {
            clearInterval(id)
            element.remove()
        }

        animationFrame += 1
    }
}

function createStreakPopup(hostname, streakAmount) {
    const popupDiv = document.createElement("div")
    popupDiv.style.all = "initial"
    popupDiv.style.width = "20rem" 
    popupDiv.style.height = "7rem"
    popupDiv.style.backgroundColor = "white"
    popupDiv.style.color = "black"
    popupDiv.style.position = "fixed"
    popupDiv.style.left =  "1rem"
    popupDiv.style.padding = "1rem"
    popupDiv.style.borderRadius = "1.5rem"
    popupDiv.style.borderWidth = "1rem"
    popupDiv.style.borderColor = "#666666"
    popupDiv.style.zIndex = "999999"

    const mainNumberDiv = document.createElement("div")
    mainNumberDiv.style.display = "flex"
    mainNumberDiv.style.height = "75%"
    mainNumberDiv.style.width = "80%"

    popupDiv.appendChild(mainNumberDiv)

    const bigNumber = document.createElement("h1")
    bigNumber.textContent = streakAmount
    bigNumber.style.marginTop = "auto"
    bigNumber.style.fontSize = "3.5rem"
    bigNumber.style.marginRight = "0.5rem"

    const middleLabelDiv = document.createElement("div")
    middleLabelDiv.style.display = "flex"
    middleLabelDiv.style.flexDirection = "column"

    const domainText = document.createElement("p")
    domainText.textContent = hostname

    const streakTextLabel = document.createElement("p")
    streakTextLabel.textContent = "streak"

    middleLabelDiv.append(domainText, streakTextLabel)
    mainNumberDiv.append(bigNumber, middleLabelDiv)

    const weekProgress = document.createElement("progress")
    weekProgress.max = 7
    weekProgress.value = streakAmount % 7 == 0 ? 7 : streakAmount % 7
    weekProgress.style.width = "70%"
    weekProgress.style.position = "relative"
    weekProgress.style.bottom = "50%"
    weekProgress.style.accentColor = "red"
    weekProgress.style.display = "inline-block"
    popupDiv.appendChild(weekProgress)

    const imageDiv = document.createElement("div")
    imageDiv.style.display = "inline-block"
    imageDiv.style.width = "25%"
    imageDiv.style.position = "relative"
    imageDiv.style.bottom = "50%"

    popupDiv.appendChild(imageDiv)

    const streakImage = document.createElement("img")

    // Change image based on week streak
    const imageUrl = streakAmount % 7 == 0 ? chrome.runtime.getURL("images/full_fire_streak.png"):
        streakAmount > 6 ? chrome.runtime.getURL("images/dim_fire_streak.png"):
        chrome.runtime.getURL("images/no_fire_streak.png")

    streakImage.src = imageUrl
    streakImage.alt = "Image of fire";
    streakImage.style.width = "100%"

    imageDiv.appendChild(streakImage)

    const weekNumberDiv = document.createElement("div")
    weekNumberDiv.style.position = "absolute"
    weekNumberDiv.style.top = "50%"
    weekNumberDiv.style.left = "50%"
    weekNumberDiv.style.transform = "translate(-50%, -50%)"

    imageDiv.appendChild(weekNumberDiv)

    const weekNumber = document.createElement("h2")
    weekNumber.textContent = Math.floor(streakAmount / 7)
    weekNumber.style.fontSize = "2rem"
    weekNumberDiv.appendChild(weekNumber)

    // Adds the popup
    const mainBody = document.body
    mainBody.appendChild(popupDiv);

    animatePopIn(popupDiv)
}

// Request page visit counts from service worker
chrome.runtime.sendMessage({action: "GET_DATA", hostname: window.location.hostname}, (response) => {
    // console.log(response.data)
    
    if(window.location.hostname in response.data){
        const hostname = window.location.hostname
        const streakAmount = response.data[hostname].streak

        createStreakPopup(hostname, streakAmount)
    }
})